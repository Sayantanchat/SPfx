declare interface ITasksCalendarStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  ListNameFieldLabel: string;
}

declare module 'TasksCalendarWebPartStrings' {
  const strings: ITasksCalendarStrings;
  export = strings;
}
/* tslint:disable */
require("./TasksCalendarWebPart.module.css");
const styles = {
  tasksCalendar: 'tasksCalendar_5b13333c',
  container: 'container_5b13333c',
  row: 'row_5b13333c',
  column: 'column_5b13333c',
  'ms-Grid': 'ms-Grid_5b13333c',
  title: 'title_5b13333c',
  subTitle: 'subTitle_5b13333c',
  description: 'description_5b13333c',
  button: 'button_5b13333c',
  label: 'label_5b13333c'
};

export default styles;
/* tslint:enable */